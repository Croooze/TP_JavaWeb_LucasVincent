package com.ipi.jva320;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jva320Application {

    public static void main(String[] args) {
        SpringApplication.run(Jva320Application.class, args);
    }

}