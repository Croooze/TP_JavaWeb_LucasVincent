package com.ipi.jva320.exception;

public class SalarieException extends Exception {

    public SalarieException(String s) {
        super(s);
    }

}
