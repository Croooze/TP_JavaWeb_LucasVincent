package com.ipi.jva320;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jva320ApplicationTests {

	@Test
	void contextLoads() {
	}

}
